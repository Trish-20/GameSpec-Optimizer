# GameSpec Hardware Detector

A small Windows **x64** console app that reads the local machine's **CPU, GPU,
and RAM** (via WMI), matches them against the GameSpec Optimizer benchmark
catalogue, and exposes the result on a **read-only loopback endpoint** so the
GameSpec website can auto-fill the hardware dropdowns.

It is published as a **single, self-contained executable** — end users do **not**
need to install the .NET SDK or set any environment variables.

---

## For end users (no developer tools required)

1. Unzip the distribution (for example `dist\GameSpec-Hardware-Detector-win-x64.zip`)
   to any folder, e.g. your Desktop.
2. Double-click **`Start-GameSpec-Hardware-Detector.bat`**.
3. Leave the black console window open. It prints the local endpoint address and
   the allowed website origin.
4. Go to the GameSpec website and click **"Detect My Hardware"**.

The executable has safe production defaults for both settings, and the launcher
sets the same values explicitly. No terminal commands or user configuration are
needed:

| Environment variable      | Value                                          |
| ------------------------- | ---------------------------------------------- |
| `GAMESPEC_ALLOWED_ORIGINS`| `https://gamespec-optimizer.onrender.com`      |
| `GAMESPEC_API_BASE_URL`   | `https://gamespec-optimizer.onrender.com/`     |

To stop the detector, close the console window or press `Ctrl+C`.

If you already have the detector running, launching it again is safe — it detects
the existing instance and exits with a friendly message instead of a port error.

---

## For developers

### Build

```powershell
dotnet build -c Release
```

### Publish (self-contained, single file, Windows x64)

```powershell
dotnet publish -c Release
```

This writes to:

```
bin\Release\net8.0-windows\win-x64\publish\
```

The published folder contains **only** what the app needs:

- `GameSpecHardwareDetector.exe` — self-contained single-file executable (bundles
  the .NET runtime and native WMI interop, so it runs on a clean Windows x64 PC).
- `Start-GameSpec-Hardware-Detector.bat` — the launcher (copied here automatically).

> The extra files in the parent `win-x64\` folder are just the intermediate,
> non-bundled build output. **Do not copy them** — the single-file `.exe` is
> complete on its own.

### Run from a developer checkout

You can run straight from the published output:

```powershell
.\bin\Release\net8.0-windows\win-x64\publish\Start-GameSpec-Hardware-Detector.bat
```

or set the variables manually and run the exe directly.

### Command-line options

- `--self-test` — runs the built-in benchmark-matching test suite (no network/UI).
- `--api-base-url <url>` — overrides `GAMESPEC_API_BASE_URL`.
- `--port <1-65535>` — overrides the default loopback port `43127`.

### Run the self-tests

```powershell
dotnet run -c Release -- --self-test
```

---

## How the website talks to the detector

- Endpoint (fixed): `http://127.0.0.1:43127/v1/hardware-match`
- The browser sends a cross-origin `GET`. The detector answers **only** when the
  request `Origin` is exactly in `GAMESPEC_ALLOWED_ORIGINS` and the `Host` is the
  IPv4 loopback address. Any other origin is rejected with HTTP 403 — arbitrary
  origins are never allowed.
- Response is JSON: `status` is `matched` / `no_match` / `catalogue_unavailable`,
  plus per-component `cpu`, `gpu`, and `ram` match details.
- Manual hardware selection on the website remains the fallback when the
  detector is not running.

## Browser permission (if needed)

Some browsers may ask for permission to access your device's local network when connecting to the Hardware Detector. If this prompt appears and clearly relates to GameSpec Optimizer and its local detector, click **Allow** to continue.

If you accidentally clicked **Block**, check your browser's site permissions and allow local-network access if that option is available.

If no permission prompt appears, no action is needed.

## Notes

The hardware detector only reads your CPU, RAM size, and GPU and nothing else
