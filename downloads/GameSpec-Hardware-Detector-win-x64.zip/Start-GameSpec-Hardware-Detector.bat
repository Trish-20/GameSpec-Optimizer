
@echo off
setlocal EnableExtensions
title GameSpec Hardware Detector

rem Always operate relative to this launcher's own folder so the detector can
rem be started from anywhere (including straight out of the distribution ZIP).
cd /d "%~dp0"

rem ---------------------------------------------------------------------------
rem Configuration baked into the launcher so end users never have to set
rem environment variables or open a terminal by hand.
rem
rem   GAMESPEC_ALLOWED_ORIGINS  exact deployed website origin (CORS allow-list)
rem   GAMESPEC_API_BASE_URL     deployed GameSpec project root (benchmark API)
rem
rem The detector reads benchmark endpoints as:  <GAMESPEC_API_BASE_URL>MODULES/api/get-*.php
rem ---------------------------------------------------------------------------
set "GAMESPEC_ALLOWED_ORIGINS=https://gamespec-optimizer.onrender.com,http://localhost:8080,http://127.0.0.1:8080"
set "GAMESPEC_API_BASE_URL=https://gamespec-optimizer.onrender.com/"

set "DETECTOR_EXE=%~dp0GameSpecHardwareDetector.exe"

echo ============================================================
echo    GameSpec Hardware Detector
echo ============================================================
echo.

rem --- Make sure the published executable is present ------------------------
if not exist "%DETECTOR_EXE%" (
    echo [ERROR] Could not find the detector executable:
    echo         "%DETECTOR_EXE%"
    echo.
    echo This launcher must sit in the same folder as
    echo GameSpecHardwareDetector.exe ^(the published, self-contained output^).
    echo.
    echo Developers: publish it first with:
    echo     dotnet publish -c Release
    echo.
    pause
    exit /b 1
)

rem --- Avoid launching a second detector instance ---------------------------
tasklist /fi "imagename eq GameSpecHardwareDetector.exe" 2>nul | find /i "GameSpecHardwareDetector.exe" >nul
if not errorlevel 1 (
    echo [INFO] GameSpec Hardware Detector is already running.
    echo.
    echo Keep the existing window open, then click
    echo "Detect My Hardware" on the GameSpec website.
    echo.
    echo Close the running detector window first if you want to restart it.
    echo.
    pause
    exit /b 0
)

echo Allowed website origin : %GAMESPEC_ALLOWED_ORIGINS%
echo Benchmark API base URL: %GAMESPEC_API_BASE_URL%
echo.
echo Starting the local detector on http://127.0.0.1:43127 ...
echo Keep this window open while using the GameSpec website.
echo.

rem --- Launch the self-contained published detector -------------------------
"%DETECTOR_EXE%"
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if not "%EXIT_CODE%"=="0" (
    echo [ERROR] The detector exited with code %EXIT_CODE%.
    echo         See the messages above for details.
    echo.
    pause
    exit /b %EXIT_CODE%
)

echo The detector has stopped.
pause
exit /b 0

